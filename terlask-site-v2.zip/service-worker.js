// Kept intentionally simple while the app is still actively changing:
// always serve fresh content so updates show immediately after redeploying.
// (Proper offline caching can be reintroduced once the app is more stable.)
self.addEventListener('install', () => { self.skipWaiting(); });
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k))))
  );
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request));
});
